#!/usr/bin/env bash
# Aligns and signs the release APK with the permanent key in signing/.
# Every build must use the SAME key, otherwise Android refuses to install it over the old one.
set -euo pipefail

: "${KS_FILE:?KS_FILE not set}" "${KS_ALIAS:?KS_ALIAS not set}" "${KS_PASS:?KS_PASS not set}"
NAME="${APK_NAME:-dafter}"
SDK="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}"
[ -n "$SDK" ] && [ -d "$SDK/build-tools" ] || { echo "Android SDK build-tools not found"; exit 1; }

VER="$(ls "$SDK/build-tools" | grep -E '^[0-9]+(\.[0-9]+)+$' | sort -V | tail -n 1)"
BT="$SDK/build-tools/$VER"
echo "Using build-tools $VER"
[ -x "$BT/zipalign" ] && [ -x "$BT/apksigner" ] || { echo "zipalign/apksigner missing in $BT"; exit 1; }

IN="$(find android/app/build/outputs/apk/release -name '*.apk' | head -n 1)"
[ -n "$IN" ] || { echo "release APK not found"; exit 1; }
echo "Input: $IN"

mkdir -p out
rm -f out/aligned.apk "out/$NAME.apk" "out/$NAME.apk.idsig"
"$BT/zipalign" -p -f 4 "$IN" out/aligned.apk
"$BT/apksigner" sign \
  --ks "$KS_FILE" --ks-key-alias "$KS_ALIAS" \
  --ks-pass "pass:$KS_PASS" --key-pass "pass:$KS_PASS" \
  --out "out/$NAME.apk" out/aligned.apk
"$BT/apksigner" verify --verbose "out/$NAME.apk"
rm -f out/aligned.apk "out/$NAME.apk.idsig"
ls -l "out/$NAME.apk"
