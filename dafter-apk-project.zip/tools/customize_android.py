#!/usr/bin/env python3
"""Applies this app's native customizations to the freshly generated Capacitor `android/` project.

Runs in CI right after `npx cap add android`. Every step is independent and defensive:
a cosmetic step that cannot be applied prints a WARNING and the build continues.
"""
import os
import re
import shutil
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
AND = ROOT / "android"
RES = AND / "app" / "src" / "main" / "res"
GRADLE = AND / "app" / "build.gradle"
GPROPS = AND / "gradle.properties"
NATIVE_RES = ROOT / "native-res"


def log(msg):
    print(msg, flush=True)


def step(name):
    def deco(fn):
        def run():
            try:
                changed = fn()
                log(f"[ok]   {name}" + (f" ({changed})" if changed else ""))
            except Exception as e:  # noqa: BLE001
                log(f"[WARN] {name} skipped: {e!r}")
        return run
    return deco


@step("icons + splash + notification icon (replace Capacitor default logo)")
def icons_and_splash():
    if not NATIVE_RES.is_dir():
        raise RuntimeError("native-res folder missing")
    removed = 0
    # the default splash is a PNG; our splash is an XML drawable with the same name,
    # so every splash.png must go first (two resources with one name break the build)
    for p in list(RES.rglob("splash.png")):
        p.unlink()
        removed += 1
    copied = 0
    for src in NATIVE_RES.rglob("*"):
        if src.is_file():
            dst = RES / src.relative_to(NATIVE_RES)
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(src, dst)
            copied += 1
    return f"removed {removed} default splash png, copied {copied} files"


@step("launch theme: dark splash background on Android 12+")
def splash_theme():
    f = RES / "values" / "styles.xml"
    text = f.read_text(encoding="utf-8")
    if "windowSplashScreenBackground" in text:
        return "already set"
    # only touch the style when it really derives from the AndroidX splash theme
    pat = re.compile(r'(<style\s+name="AppTheme\.NoActionBarLaunch"\s+parent="Theme\.SplashScreen"\s*>)')
    if not pat.search(text):
        raise RuntimeError("launch style not in the expected form; leaving it unchanged")
    text = pat.sub(r'\1\n        <item name="windowSplashScreenBackground">#0E1B22</item>', text, count=1)
    f.write_text(text, encoding="utf-8")
    return "patched"


@step("versionCode / versionName")
def version():
    run = os.environ.get("RUN_NUMBER", "1")
    if not run.isdigit():
        run = "1"
    # versionCode = minutes since 1970: it always grows, even if this project is later built
    # from a different GitHub account/repository (where the build number would restart at 1)
    code = int(time.time() // 60)
    text = GRADLE.read_text(encoding="utf-8")
    text, n1 = re.subn(r"versionCode(\s*=?\s*)\d+", rf"versionCode\g<1>{code}", text, count=1)
    text, n2 = re.subn(r'versionName(\s*=?\s*)"[^"]*"', rf'versionName\g<1>"1.0.{run}"', text, count=1)
    if n1 != 1 or n2 != 1:
        raise RuntimeError("versionCode/versionName lines not found")
    GRADLE.write_text(text, encoding="utf-8")
    return f"versionCode={code}, versionName=1.0.{run}"


@step("gradle memory")
def gradle_mem():
    line = "org.gradle.jvmargs=-Xmx3072m -Dfile.encoding=UTF-8"
    text = GPROPS.read_text(encoding="utf-8") if GPROPS.exists() else ""
    if re.search(r"^org\.gradle\.jvmargs=", text, flags=re.M):
        text = re.sub(r"^org\.gradle\.jvmargs=.*$", line, text, count=1, flags=re.M)
    else:
        text += ("\n" if text and not text.endswith("\n") else "") + line + "\n"
    GPROPS.write_text(text, encoding="utf-8")
    return "Xmx3072m"


@step("gradle: skip release lint checks")
def lint_off():
    text = GRADLE.read_text(encoding="utf-8")
    if "checkReleaseBuilds" in text:
        return "already set"
    text += (
        "\n// added by tools/customize_android.py: lint is not needed to produce a sideloaded APK\n"
        "android {\n    lint {\n        checkReleaseBuilds = false\n        abortOnError = false\n    }\n}\n"
    )
    GRADLE.write_text(text, encoding="utf-8")
    return "added"


def main():
    if not AND.is_dir():
        log("ERROR: android/ folder not found. Run `npx cap add android` first.")
        sys.exit(1)
    for fn in (icons_and_splash, splash_theme, version, gradle_mem, lint_off):
        fn()
    log("customization finished")


if __name__ == "__main__":
    main()
